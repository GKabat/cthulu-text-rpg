# KONTEKST PROJEKTU: Tekstowe RPG Cthulhu — Cactus Studio

> **Przeznaczenie tego dokumentu:** jest to kompletny kontekst dla modelu językowego (LLM), który ma pomagać zespołowi w dalszej pracy nad projektem. Zawiera WSZYSTKIE podjęte decyzje architektoniczne, uzgodnienia, struktury danych, podział ról, workflow i zasady. LLM powinien traktować ten dokument jako źródło prawdy i nie proponować rozwiązań sprzecznych z poniższymi ustaleniami, chyba że zespół explicite poprosi o rewizję danej decyzji.

---

## 1. INFORMACJE OGÓLNE

- **Nazwa studia:** Cactus Studio
- **Projekt:** Tekstowe RPG w klimacie Call of Cthulhu z prostym GUI
- **Przedmiot:** Inżynieria Systemów, I rok IT
- **Zespół:** 5 osób, poziom podstawowy Python, brak wcześniejszego doświadczenia z Git/GitHub
- **Czas realizacji:** ~3 tygodnie (21 dni roboczych)
- **Język programowania:** Python 3
- **Repozytorium:** GitHub, wspólne repo, branch main (bez feature branchy na tym etapie)

### Absolutne restrykcje
- Zespół uczy się programowania — priorytetem jest ZROZUMIENIE, nie gotowy kod
- Rozwiązania powinny być wyjaśniane niskopoziomowo (dlaczego, nie tylko jak)
- Każda sugestia powinna być proporcjonalna do poziomu zespołu (pierwszy rok, podstawowy Python)

---

## 2. ZAKRES MVP (co robimy)

### W zakresie MVP:
1. **Silnik fabularny** — wczytanie drzewka decyzyjnego z pliku JSON, nawigacja po węzłach, obsługa wyborów gracza
2. **Prosta mechanika RPG** — statystyki postaci (HP, Sanity), rzuty kością wpływające na wynik, prosta walka/sprawdzenia
3. **GUI w Tkinter** — okno z polem tekstowym, 2-3 przyciski wyboru, pasek stanu HP/Sanity, wyświetlanie obrazków
4. **Dane w JSON** — cała fabuła i konfiguracja w czytelnych plikach JSON
5. **Pixel art** — grafiki scen i potworów w formacie PNG

### Świadomie WYRZUCONE z zakresu:
- ❌ System zapisu/odczytu gry (Save/Load) — zbyt złożona serializacja stanu
- ❌ Baza danych SQL/SQLite — overkill, zastąpiona plikami JSON
- ❌ Pygame — zbyt wysoki próg wejścia, zastąpiony Tkinterem
- ❌ System levelowania/rozwoju postaci — zbędna złożoność
- ❌ Złożony ekwipunek — ewentualnie post-MVP
- ❌ Feature branche w Git — zespół nie zna Gita, pracują na main
- ❌ Automatyczne testy — zastąpione testowaniem eksploracyjnym (ręcznym)

### Post-MVP (jeśli starczy czasu):
- System walki (rozbudowany)
- Ekwipunek
- Migracja z Tkinter na Pygame
- Muzyka/efekty dźwiękowe
- System zapisu

---

## 3. ARCHITEKTURA I DECYZJE TECHNICZNE

### 3.1. Dlaczego JSON zamiast SQL
Pliki JSON są bezpośrednio czytelne, edytowalne ręcznie, nie wymagają dodatkowej warstwy narzędzi i uczą fundamentalnych struktur danych Pythona (słowniki, listy). SQLite wymagałby nauki SQL, ORM, schematów tabel i połączeń — nieproporcjonalny koszt edukacyjny.

### 3.2. Dlaczego Tkinter zamiast Pygame
Tkinter jest wbudowany w Pythona (zero instalacji), ma łagodniejszą krzywą nauki i wystarczy do gry wyświetlającej tekst + przyciski + obrazki. Pygame wymaga obsługi pętli zdarzeń, rysowania klatek, zarządzania stanami ekranu — overkill dla gry tekstowej.

### 3.3. Dlaczego jeden plik per osoba
Jeden plik (np. mechanics.py) zamiast folderu z wieloma plikami (mechanics/dice.py, mechanics/combat.py) eliminuje problemy z importami, pakietami Pythona (__init__.py), i minimalizuje konflikty w Git. Wewnątrz pliku funkcje są pogrupowane komentarzami-sekcjami. Podział na wiele plików ma sens dopiero gdy plik przekroczy 300-400 linii — wtedy właściciel sam dzieli.

### 3.4. Zasada data-driven design
Silnik gry NIE "zna" fabuły. Czyta dane z JSON i operuje na nich generycznie. Zmiana całej historii nie wymaga zmiany ani jednej linii kodu w engine.py. Treść jest w danych, logika jest w kodzie.

### 3.5. Zasada jednego stanu gry
Cały stan gry (HP, Sanity, obecny węzeł, odwiedzone miejsca) trzymany jest w JEDNYM obiekcie/słowniku w game_state.py. Nigdy nie rozrzucamy stanu po wielu zmiennych globalnych.

---

## 4. STRUKTURA PROJEKTU

```
cthulhu-text-rpg/
├── main.py              ← punkt wejścia gry, łączy moduły (Osoba 5)
├── engine.py            ← silnik fabularny, nawigacja po drzewku (Osoba 2)
├── game_state.py        ← zarządzanie stanem gry (Osoba 2)
├── mechanics.py         ← mechaniki RPG: kości, obrażenia, sanity (Osoba 3)
├── gui.py               ← interfejs graficzny Tkinter (Osoba 4)
├── data/
│   ├── story.json       ← drzewko fabularne (Osoba 1)
│   └── config.json      ← konfiguracja startowa (Osoba 1)
├── assets/
│   └── (pliki .png)     ← grafiki pixel art (Osoba 5)
├── .gitignore           ← Python template (automatyczny)
└── README.md            ← dokumentacja projektu (Osoba 5)
```

### Właścicielstwo plików (zasada: jeden plik = jeden właściciel)

| Plik | Właściciel | Inni NIE edytują |
|------|-----------|-----------------|
| data/story.json | Osoba 1 | Osoby 2, 3, 4, 5 |
| data/config.json | Osoba 1 | Osoby 2, 3, 4, 5 |
| engine.py | Osoba 2 | Osoby 1, 3, 4, 5 |
| game_state.py | Osoba 2 | Osoby 1, 3, 4, 5 |
| mechanics.py | Osoba 3 | Osoby 1, 2, 4, 5 |
| gui.py | Osoba 4 | Osoby 1, 2, 3, 5 |
| main.py | Osoba 5 | Osoby 1, 2, 3, 4 |
| assets/* | Osoba 5 | Osoby 1, 2, 3, 4 |
| README.md | Osoba 5 | Osoby 1, 2, 3, 4 |

---

## 5. STRUKTURA DANYCH

### 5.1. Węzeł fabularny (story.json)

Plik story.json to słownik, gdzie kluczem jest id węzła, a wartością obiekt opisujący scenę:

```
{
  "start": {
    "tekst": "Stoisz przed starym domem na wzgórzu...",
    "obrazek": "assets/dom_wzgorze.png",
    "wybory": [
      {
        "tekst": "Wejdź do środka",
        "cel": "korytarz",
        "warunek": null
      },
      {
        "tekst": "Uciekaj",
        "cel": "ucieczka_start",
        "warunek": null
      },
      {
        "tekst": "Spróbuj wyważyć drzwi",
        "cel": "drzwi_sukces",
        "warunek": {"rzut_koscia": true, "prog": 12}
      }
    ],
    "efekt": null,
    "zakonczone": false
  },
  "korytarz": {
    "tekst": "Ciemny korytarz ciągnie się w głąb domu...",
    "obrazek": "assets/korytarz.png",
    "wybory": [...],
    "efekt": {"sanity": -10},
    "zakonczone": false
  },
  "koniec_dobry": {
    "tekst": "Udało ci się uciec z domu...",
    "obrazek": "assets/koniec.png",
    "wybory": [],
    "efekt": null,
    "zakonczone": true
  }
}
```

Kluczowe pola węzła:
- **tekst** (string): opis sceny wyświetlany graczowi
- **obrazek** (string | null): ścieżka do grafiki PNG
- **wybory** (lista): każdy wybór ma tekst, cel (id następnego węzła), opcjonalny warunek
- **warunek** w wyborze: null = brak warunku; obiekt = wymagane sprawdzenie (np. rzut kością, minimalny HP/Sanity)
- **efekt** (obiekt | null): zmiana stanu po wejściu do węzła (np. {"sanity": -10, "hp": -5})
- **zakonczone** (bool): true = węzeł kończy grę

### 5.2. Konfiguracja startowa (config.json)

```
{
  "tytul": "Cień nad Arkham",
  "wersja": "1.0",
  "postac": {
    "nazwa": "Badacz",
    "hp": 100,
    "sanity": 100
  },
  "start_wezel": "start"
}
```

### 5.3. Stan gry (game_state.py)

Stan gry to słownik (lub prosta klasa) przechowywany w pamięci:

```
game_state = {
  "obecny_wezel": "start",
  "hp": 100,
  "sanity": 100,
  "odwiedzone": ["start"],
  "nazwa_postaci": "Badacz"
}
```

Stan jest JEDYNYM źródłem prawdy o tym, "gdzie jest gracz" i "jaki jest jego stan". Wszystkie moduły czytają/modyfikują ten sam obiekt stanu.

---

## 6. INTERFEJSY MODUŁÓW (kontrakt między osobami)

### 6.1. engine.py (Osoba 2)

```
wczytaj_fabule(sciezka: str) -> dict
    # Wczytuje story.json i zwraca słownik z drzewkiem fabularnym

pobierz_wezel(fabula: dict, id_wezla: str) -> dict
    # Zwraca słownik węzła: {tekst, obrazek, wybory, efekt, zakonczone}

wykonaj_wybor(fabula: dict, wybor: dict, stan: dict) -> str
    # Przetwarza wybór gracza, zwraca id następnego węzła
    # Jeśli wybór ma warunek — sprawdza go

sprawdz_warunek(warunek: dict, stan: dict) -> bool
    # Sprawdza czy gracz spełnia warunek (HP, Sanity, rzut kością)

czy_koniec(wezel: dict) -> bool
    # Sprawdza czy węzeł jest zakończeniem gry
```

### 6.2. game_state.py (Osoba 2)

```
inicjalizuj_stan(config: dict) -> dict
    # Tworzy nowy stan gry na podstawie config.json

aktualizuj_stan(stan: dict, efekt: dict) -> dict
    # Aplikuje efekt węzła na stan (zmiana HP, Sanity)

pobierz_stan(stan: dict) -> dict
    # Zwraca obecny stan (może robić kopię)
```

### 6.3. mechanics.py (Osoba 3)

```
rzut_koscia(zakres: int = 20) -> int
    # Zwraca losową liczbę 1-zakres (domyślnie d20)

sprawdz_rzut(wynik: int, prog: int) -> bool
    # wynik >= prog → True (sukces), inaczej False

oblicz_obrazenia(atak: int, obrona: int) -> int
    # Zwraca max(0, atak - obrona + modyfikator)

modyfikuj_sanity(typ_zdarzenia: str, stan: dict) -> int
    # Zwraca nową wartość Sanity po zdarzeniu

czy_zyje(hp: int) -> bool
    # hp > 0 → True
```

Wszystkie funkcje w mechanics.py to CZYSTE FUNKCJE — nie modyfikują stanu bezpośrednio, nie wyświetlają tekstu, nie rysują GUI. Przyjmują wejście, zwracają wynik.

### 6.4. gui.py (Osoba 4)

```
utworz_okno() -> Tk
    # Inicjalizuje okno Tkinter z layoutem gry

wyswietl_scene(tekst: str, obrazek: str | None)
    # Aktualizuje pole opisu i opcjonalnie obrazek

wyswietl_wybory(lista_wyborow: list, callback: function)
    # Generuje przyciski dynamicznie; kliknięcie wywołuje callback

aktualizuj_statystyki(hp: int, sanity: int)
    # Odświeża pasek stanu (HP: XX | Sanity: YY)

wyswietl_wynik_rzutu(tekst: str)
    # Pokazuje wynik rzutu kością (popup lub pole tekstowe)

ekran_koncowy(typ: str, tekst: str)
    # Wyświetla ekran zakończenia gry (dobry/zły)
```

### 6.5. main.py (Osoba 5)

```
uruchom_gre()
    # Punkt wejścia: wczytuje dane, inicjalizuje stan,
    # tworzy okno GUI, łączy engine z GUI przez callbacki

obsluz_wybor(numer_wyboru: int)
    # Callback wywoływany przez GUI po kliknięciu:
    # engine.wykonaj_wybor() → aktualizuj stan → odśwież GUI
```

main.py to "klej" — nie zawiera logiki gry ani rysowania GUI. Importuje moduły i łączy je ze sobą.

---

## 7. PODZIAŁ RÓL W ZESPOLE

### Osoba 1: Architekt Danych i Fabuły
- Projektuje i tworzy pliki JSON (story.json, config.json)
- Odpowiada za treść fabularną i balans mechanik (wartości HP, Sanity, progi rzutów)
- Jest "game designerem" zespołu
- Kluczowa koncepcja: data-driven design

### Osoba 2: Programista Silnika Fabularnego
- Pisze engine.py (nawigacja po drzewku) i game_state.py (zarządzanie stanem)
- Jest "mózgiem" gry — decyduje co się dzieje po wyborze gracza
- Kluczowa koncepcja: separacja odpowiedzialności

### Osoba 3: Programista Mechanik RPG
- Pisze mechanics.py (rzuty kośćmi, obrażenia, Sanity, sprawdzenia stanu)
- Dostarcza czyste funkcje obliczeniowe wywoływane przez silnik (Osoba 2)
- Kluczowa koncepcja: czyste funkcje (wejście → obliczenie → wyjście)

### Osoba 4: Programista Interfejsu
- Pisze gui.py (okno Tkinter, przyciski, tekst, pasek stanu, obrazki)
- Wyświetla to co dostarczy silnik, przekazuje kliknięcia gracza z powrotem
- Kluczowa koncepcja: callback i inversion of control

### Osoba 5: Integrator i QA
- Pisze main.py, zarządza repozytorium Git, testuje całość
- Tworzy grafiki pixel art, pisze README.md
- Jest "pierwszą linią pomocy Git" i ekspertem od rozwiązywania konfliktów
- Kluczowa koncepcja: testowanie eksploracyjne

---

## 8. WORKFLOW SDLC

### Faza 0: Przygotowanie środowiska (Dzień 1-2)
- Instalacja Python, VS Code, Git
- Założenie repo GitHub, klonowanie, testowe commity
- Ustalenie struktury folderów

### Faza 1: Analiza i projektowanie (Dzień 2-4)
- Narysowanie drzewka fabularnego na kartce (15-20 węzłów)
- Zaprojektowanie struktur danych (JSON, game_state)
- Zdefiniowanie interfejsów funkcji (PISEMNIE — kontrakt między modułami)
- Szkic interfejsu GUI

### Faza 2: Prototyp "kręgosłup" (Dzień 4-7)
- CAŁY ZESPÓŁ RAZEM buduje minimalną działającą wersję
- 3-5 węzłów w JSON, silnik wczytuje i przechodzi, GUI wyświetla
- 🎯 KAMIEŃ MILOWY (Dzień 7): gra działa end-to-end (brzydka, 3 węzły, ale DZIAŁA)

### Faza 3: Rozbudowa równoległa (Dzień 7-14)
- Każdy rozbudowuje swoją część kręgosłupa
- Fabuła rośnie do 15-20 węzłów, mechaniki się rozbudowują, GUI się dopieszcza
- Integracja co 2 dni (nie na końcu!)

### Faza 4: Integracja i testy (Dzień 14-18)
- Łączenie modułów, naprawianie błędów
- Testowanie scenariuszy (przejście całej gry różnymi ścieżkami)
- Dodanie try/except w krytycznych miejscach
- Testy graniczne (HP=0, Sanity=0, brak wyborów)

### Faza 5: Polerowanie i oddanie (Dzień 18-21)
- Poprawki wizualne, pixel art, estetyka
- README.md z instrukcją
- Przygotowanie prezentacji
- 🎯 KAMIEŃ MILOWY (Dzień 21): gra gotowa do oddania

---

## 9. ZASADY GIT

### Złoty schemat (codziennie):
1. `git pull` — PRZED rozpoczęciem pracy
2. `git add .` + `git commit -m "opis"` — co 30-60 minut
3. `git push` — GDY kończysz sesję

### Zasady:
- Jeden plik = jeden właściciel. Nie edytuj cudzych plików.
- Opisy commitów po polsku, konkretnie: "Dodałem 5 węzłów do story.json" (NIE "update")
- Wszyscy na branchu main (bez feature branchy — zbyt wcześnie)
- Przy konflikcie: właściciel pliku rozwiązuje, Osoba 5 pomaga

---

## 10. ZIDENTYFIKOWANE RYZYKA

| Ryzyko | Mitygacja |
|--------|-----------|
| Rozjazd stanu gry | Cały stan w jednym obiekcie game_state |
| "Big bang" integracyjny | Kręgosłup budowany razem (Faza 2), integracja co 2 dni |
| Brak umowy o interfejsach | Kontrakt pisemny w Fazie 1 (sekcja 6 tego dokumentu) |
| Konflikty w Git | Jeden plik = jeden właściciel, pull przed pracą |
| Perfekcjonizm ("ładne > działające") | Zasada: najpierw DZIAŁA, potem jest ŁADNE |
| Brak obsługi błędów | try/except od Fazy 4, komunikaty zamiast crash |
| Hardkodowanie danych | Dane w JSON, logika w Pythonie, silnik nie zna fabuły |

---

## 11. DIAGRAM USE CASE (opis)

Aktor: Gracz (jedyny użytkownik systemu)

Przypadki użycia:
- **Uruchomienie gry** —«include»→ Czytanie opisu sceny —«include»→ Dokonanie wyboru
- **Czytanie opisu sceny** —«extend»→ Wyświetlenie grafiki sceny (nie każda scena ma grafikę)
- **Dokonanie wyboru** —«extend»→ Zakończenie gry (tylko niektóre wybory kończą grę)
- **Dokonanie wyboru** —«extend»→ Spotkanie przeciwnika (opcjonalne)
- **Spotkanie przeciwnika** —«extend»→ Rzut kością (nie każde spotkanie wymaga rzutu)
- **Rzut kością** —«extend»→ Utrata HP/Sanity (nie każdy rzut skutkuje stratą)

Ważne: strzałki «extend» idą OD rozszerzenia DO bazy (odwrotnie niż intuicja).

---

## 12. KLUCZOWE ZASADY (podsumowanie)

1. MVP = minimum które działa end-to-end. Lepiej 15 węzłów działających niż 50 niedokończonych.
2. Kręgosłup budujemy RAZEM, potem rozchodzimy się do specjalizacji.
3. Git pull przed pracą, git push po pracy. Jeden plik = jeden właściciel.
4. Dane (JSON) osobno, logika (Python) osobno. Silnik nie zna fabuły.
5. Najpierw DZIAŁA, potem jest ŁADNE. Estetyka na końcu.
6. Integracja co 2 dni, nie na końcu projektu. 30% czasu na testy.
7. Pięć osób = pięć głównych plików. Każdy plik ma jednego właściciela.

---

*Dokument wygenerowany: marzec 2026 | Cactus Studio | Projekt IS, I rok IT*
